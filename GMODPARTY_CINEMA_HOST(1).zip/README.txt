GMOD PARTY CINEMA — hosted player page
======================================
1. Upload youtube.html to any web server you control that serves over HTTPS
   (your FastDL web domain, GitHub Pages, Cloudflare Pages, Netlify, etc.).
   Example result URL:  https://yourdomain.tld/gpcinema/youtube.html

2. On the GAME server console (or server.cfg), set the base folder URL:
     gp_cinema_url "https://yourdomain.tld/gpcinema/"
   (trailing slash optional; the game appends youtube.html)

3. That's it. Screens will load the hosted page -> YouTube plays with NO Error 153,
   plus distance-based volume + sync. Leave gp_cinema_url empty to use the built-in
   direct-embed fallback (plays, but full-volume on/off instead of smooth falloff).
